const express = require('express');
const router = express.Router();

// Placeholder for holiday CRUD logic

module.exports = router;
